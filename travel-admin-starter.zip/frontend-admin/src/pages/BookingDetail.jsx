import React, {useEffect, useState} from 'react';
import API from '../api';
import { useParams } from 'react-router-dom';
export default function BookingDetail(){
  const { id } = useParams();
  const [booking,setBooking] = useState(null);
  const [status, setStatus] = useState('');
  useEffect(()=>{ API.get('/api/admin/bookings/'+id).then(r=>{ setBooking(r.data); setStatus(r.data.status); }).catch(()=>{}); },[id]);
  async function updateStatus(){
    await API.post(`/api/admin/bookings/${id}/status`, { status });
    alert('Updated'); 
  }
  async function uploadTicket(e){
    const f = e.target.files[0];
    const fd = new FormData(); fd.append('ticket', f);
    await API.post(`/api/admin/bookings/${id}/ticket`, fd, { headers: {'Content-Type':'multipart/form-data'} });
    alert('Uploaded ticket');
  }
  if(!booking) return <div style={{padding:20}}>Loading...</div>;
  return <div style={{padding:20}}>
    <h3>Booking #{id}</h3>
    <div>User: {booking.user_email}</div>
    <div>From: {booking.from_city} → {booking.to_city}</div>
    <div style={{marginTop:10}}>Status:
      <select value={status} onChange={e=>setStatus(e.target.value)}>
        <option>pending</option><option>confirmed</option><option>ticketed</option><option>cancelled</option>
      </select>
      <button onClick={updateStatus} style={{marginLeft:8}}>Update</button>
    </div>
    <div style={{marginTop:12}}>
      Upload Ticket PDF: <input type="file" accept=".pdf" onChange={uploadTicket} />
    </div>
  </div>
}
