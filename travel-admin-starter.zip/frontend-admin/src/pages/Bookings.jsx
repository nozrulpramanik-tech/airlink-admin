import React, {useEffect, useState} from 'react';
import API from '../api';
import { Link } from 'react-router-dom';

export default function Bookings(){
  const [list,setList] = useState([]);
  useEffect(()=>{ API.get('/api/admin/bookings').then(r=>setList(r.data.data)).catch(()=>{}); },[]);
  return <div style={{padding:20}}>
    <h2>Bookings</h2>
    <table style={{width:'100%', borderCollapse:'collapse'}}>
      <thead><tr><th style={{borderBottom:'1px solid #ddd'}}>ID</th><th style={{borderBottom:'1px solid #ddd'}}>User</th><th style={{borderBottom:'1px solid #ddd'}}>From</th><th style={{borderBottom:'1px solid #ddd'}}>To</th><th style={{borderBottom:'1px solid #ddd'}}>Status</th><th style={{borderBottom:'1px solid #ddd'}}>Action</th></tr></thead>
      <tbody>{list.map(b=>(
        <tr key={b.id}>
          <td>{b.id}</td>
          <td>{b.user_email||'—'}</td>
          <td>{b.from_city}</td>
          <td>{b.to_city}</td>
          <td>{b.status}</td>
          <td><Link to={'/bookings/'+b.id}>Open</Link></td>
        </tr>
      ))}</tbody>
    </table>
  </div>
}
