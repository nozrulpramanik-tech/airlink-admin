const pool = require('../pool');
exports.list = async (req,res)=>{
  const [rows] = await pool.query('SELECT * FROM users ORDER BY created_at DESC LIMIT 1000');
  res.json({data:rows});
};
