import React, {useState} from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { setAuthToken } from '../api';

export default function Login(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate();
  async function onLogin(){
    try{
      const cred = await signInWithEmailAndPassword(auth, email, password);
      const token = await cred.user.getIdToken();
      localStorage.setItem('admin_token', token);
      setAuthToken(token);
      nav('/dashboard');
    }catch(e){ alert(e.message); }
  }
  return <div style={{maxWidth:420, margin:'80px auto', padding:24, background:'#fff', borderRadius:12}}>
    <h2>Admin Login</h2>
    <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
    <input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
    <button onClick={onLogin}>Login</button>
  </div>
}
