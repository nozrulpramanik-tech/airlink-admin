const pool = require('../pool');
exports.list = async (req,res)=>{
  const [rows] = await pool.query('SELECT t.*, u.email FROM transactions t LEFT JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 500');
  res.json({data:rows});
};
