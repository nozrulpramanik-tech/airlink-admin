CREATE DATABASE IF NOT EXISTS travel_admin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE travel_admin;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  firebase_uid VARCHAR(128) UNIQUE,
  email VARCHAR(255),
  phone VARCHAR(32),
  name VARCHAR(200),
  role VARCHAR(50) DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE,
  name VARCHAR(200),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bookings (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  type ENUM('flight','train','bus','hotel','package') DEFAULT 'flight',
  from_city VARCHAR(200),
  to_city VARCHAR(200),
  depart_date DATE,
  return_date DATE NULL,
  pax JSON NULL,
  cabin VARCHAR(80) DEFAULT 'Any',
  fare_type VARCHAR(80) DEFAULT 'Regular',
  status ENUM('pending','confirmed','ticketed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE tickets (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  booking_id BIGINT,
  admin_id INT,
  file_path VARCHAR(512),
  issued_at TIMESTAMP NULL,
  note TEXT,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
);

CREATE TABLE transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  type ENUM('deposit','withdrawal','refund','fare') DEFAULT 'fare',
  amount DECIMAL(12,2),
  reference VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE admin_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT,
  action VARCHAR(255),
  meta JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
