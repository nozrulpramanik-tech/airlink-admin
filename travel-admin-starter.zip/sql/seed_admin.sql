USE travel_admin;
INSERT INTO admins (email, name) VALUES ('pramaniknozrul@gmail.com', 'Nozrul Pramanik') ON DUPLICATE KEY UPDATE name=VALUES(name);
