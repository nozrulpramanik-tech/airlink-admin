import React, {useEffect, useState} from 'react';
import API from '../api';
export default function Users(){
  const [list,setList] = useState([]);
  useEffect(()=>{ API.get('/api/admin/users').then(r=>setList(r.data.data)).catch(()=>{}); },[]);
  return <div style={{padding:20}}>
    <h2>Users</h2>
    <table style={{width:'100%'}}>
      <thead><tr><th>ID</th><th>Email</th><th>Phone</th><th>Name</th></tr></thead>
      <tbody>{list.map(u=>(
        <tr key={u.id}>
          <td>{u.id}</td><td>{u.email}</td><td>{u.phone}</td><td>{u.name}</td>
        </tr>
      ))}</tbody>
    </table>
  </div>
}
