const pool = require('../pool');
module.exports = async function requireAdmin(req, res, next) {
  try {
    const email = req.firebaseUser.email;
    if(!email) return res.status(403).json({error:'No email in token'});
    const [rows] = await pool.query('SELECT * FROM admins WHERE email = ?', [email]);
    if(rows.length === 0) return res.status(403).json({ error:'Admin privileges required' });
    req.admin = rows[0];
    next();
  } catch(err) {
    console.error(err);
    res.status(500).json({error:'Server error'});
  }
};
