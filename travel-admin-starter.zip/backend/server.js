require('dotenv').config();
const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');
const verifyFirebaseToken = require('./middleware/verifyFirebaseToken');
const requireAdmin = require('./middleware/requireAdmin');
const pool = require('./pool');

admin.initializeApp({ credential: admin.credential.cert(require(process.env.FIREBASE_SERVICE_ACCOUNT_PATH)) });

const bookings = require('./controllers/bookings');
const users = require('./controllers/users');
const finance = require('./controllers/finance');
const multer = require('multer');
const upload = multer({ dest: './uploads/' });

const app = express();
app.use(cors()); app.use(express.json());

// Public test
app.get('/api/ping', (req,res)=>res.json({ok:true}));

// Admin routes
app.get('/api/admin/bookings', verifyFirebaseToken, requireAdmin, bookings.list);
app.get('/api/admin/bookings/:id', verifyFirebaseToken, requireAdmin, bookings.get);
app.post('/api/admin/bookings/:id/status', verifyFirebaseToken, requireAdmin, bookings.updateStatus);
app.post('/api/admin/bookings/:id/ticket', verifyFirebaseToken, requireAdmin, upload.single('ticket'), bookings.uploadTicket);

app.get('/api/admin/users', verifyFirebaseToken, requireAdmin, users.list);
app.get('/api/admin/transactions', verifyFirebaseToken, requireAdmin, finance.list);

const PORT = process.env.PORT || 8080;
app.listen(PORT, ()=>console.log('Backend running on', PORT));
