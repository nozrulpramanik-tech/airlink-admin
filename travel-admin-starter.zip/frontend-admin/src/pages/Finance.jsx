import React, {useEffect, useState} from 'react';
import API from '../api';
export default function Finance(){
  const [list,setList] = useState([]);
  useEffect(()=>{ API.get('/api/admin/transactions').then(r=>setList(r.data.data)).catch(()=>{}); },[]);
  return <div style={{padding:20}}>
    <h2>Transactions</h2>
    <table style={{width:'100%'}}>
      <thead><tr><th>ID</th><th>User</th><th>Type</th><th>Amount</th><th>Date</th></tr></thead>
      <tbody>{list.map(t=>(
        <tr key={t.id}>
          <td>{t.id}</td><td>{t.email}</td><td>{t.type}</td><td>{t.amount}</td><td>{t.created_at}</td>
        </tr>
      ))}</tbody>
    </table>
  </div>
}
