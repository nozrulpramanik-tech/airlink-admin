const admin = require('firebase-admin');
module.exports = async function verifyFirebaseToken(req, res, next) {
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({error:'No token'});
  const token = auth.replace('Bearer ','');
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.firebaseUser = decoded;
    next();
  } catch (e) {
    console.error('Token verify error', e.message);
    return res.status(401).json({ error: 'Invalid token' });
  }
};
