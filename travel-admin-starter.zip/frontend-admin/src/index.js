import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Bookings from './pages/Bookings';
import BookingDetail from './pages/BookingDetail';
import Users from './pages/Users';
import Finance from './pages/Finance';
import './styles.css';

function App(){
  return <BrowserRouter>
    <Routes>
      <Route path='/' element={<Login/>} />
      <Route path='/dashboard' element={<Dashboard/>} />
      <Route path='/bookings' element={<Bookings/>} />
      <Route path='/bookings/:id' element={<BookingDetail/>} />
      <Route path='/users' element={<Users/>} />
      <Route path='/finance' element={<Finance/>} />
    </Routes>
  </BrowserRouter>;
}

createRoot(document.getElementById('root')).render(<App/>);
