import React, {useEffect, useState} from 'react';
import API from '../api';

export default function Dashboard(){
  const [metrics, setMetrics] = useState({});
  useEffect(()=>{ async function load(){ try{
    const b = await API.get('/api/admin/bookings'); const u = await API.get('/api/admin/users'); const t = await API.get('/api/admin/transactions');
    setMetrics({ bookings: b.data.data.length, users: u.data.data.length, transactions: t.data.data.length });
  }catch(e){ console.error(e) } } load(); },[]);
  return <div style={{padding:20}}>
    <h1>Admin Dashboard</h1>
    <div style={{display:'flex', gap:12}}>
      <div style={{padding:14,background:'#fff',borderRadius:8}}>Bookings: {metrics.bookings||0}</div>
      <div style={{padding:14,background:'#fff',borderRadius:8}}>Users: {metrics.users||0}</div>
      <div style={{padding:14,background:'#fff',borderRadius:8}}>Transactions: {metrics.transactions||0}</div>
    </div>
  </div>
}
