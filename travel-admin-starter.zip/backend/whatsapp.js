const twilio = require('twilio');
const axios = require('axios');

async function sendWhatsAppViaTwilio(toPhone, message){
  // toPhone should be in international format e.g. +918638736500
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_WHATSAPP_FROM; // e.g. whatsapp:+14155238886
  if(!sid || !token || !from) throw new Error('Twilio not configured');
  const client = twilio(sid, token);
  const res = await client.messages.create({
    from,
    to: 'whatsapp:' + toPhone.replace(/[^0-9+]/g,''),
    body: message
  });
  return res;
}

async function sendWhatsAppVia360dialog(toPhone, message){
  // 360dialog example: send text message
  const token = process.env.DIALOG_API_TOKEN;
  const url = process.env.DIALOG_API_URL || 'https://waba.360dialog.io/v1/messages';
  if(!token) throw new Error('360dialog token missing');
  const payload = {
    to: toPhone.replace(/[^0-9]/g,''),
    type: 'text',
    text: { body: message }
  };
  const res = await axios.post(url, payload, { headers: { 'D360-API-KEY': token, 'Content-Type':'application/json' } });
  return res.data;
}

module.exports = { sendWhatsAppViaTwilio, sendWhatsAppVia360dialog };
