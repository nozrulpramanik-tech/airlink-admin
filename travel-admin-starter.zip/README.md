# Travel Admin Starter (Firebase Auth + Node.js + MySQL + React Admin)

This repository is a starter template that includes:
- Backend (Node.js + Express) that verifies Firebase ID tokens and exposes admin routes.
- Frontend admin (React) — login with Firebase, dashboard, bookings list, booking detail, users, transactions.
- SQL schema to create required tables.
- WhatsApp ticket sending integration (Twilio and 360dialog examples).

## What I packaged for you
- backend/ : Node server & controllers
- frontend-admin/ : Minimal React admin app
- sql/ : schema.sql and seed_admin.sql

## Quick start (backend)
1. Create MySQL database and run `sql/schema.sql` then `sql/seed_admin.sql`.
2. Create Firebase project, enable Email/Phone auth, and download Service Account JSON to `backend/serviceAccountKey.json`.
3. Copy `backend/.env.example` to `backend/.env` and fill values (DB, Firebase path, Twilio or 360dialog keys).
4. Install and run:
   ```bash
   cd backend
   npm install
   node server.js
   ```
5. Backend will run on `http://localhost:8080` by default.

## Quick start (frontend-admin)
1. Edit `frontend-admin/src/firebase.js` and add your Firebase Web config.
2. Set `REACT_APP_API_URL` to your backend URL if different.
3. Install and run:
   ```bash
   cd frontend-admin
   npm install
   npm start
   ```
4. Open `http://localhost:3000`, sign in with an admin user (email must exist in `admins` table).

## WhatsApp ticket sending
- Two options included:
  1. **Twilio (recommended easy start)**: set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_FROM` in `.env`.
  2. **360dialog**: set `DIALOG_API_TOKEN` and optional `DIALOG_API_URL`.

When admin uploads a ticket PDF using `/api/admin/bookings/:id/ticket`, the backend will:
- Save the file to `backend/uploads/`
- Insert a record into `tickets` table
- Try to send a WhatsApp text message to the user's phone with a link to download the ticket (requires FILES_BASE_URL or S3 URL)

## GitHub-ready
This project is ready to be pushed to GitHub. Suggested commands:
```bash
git init
git add .
git commit -m "Initial travel-admin starter"
# create repo on GitHub and push:
git remote add origin git@github.com:your-username/travel-admin-starter.git
git branch -M main
git push -u origin main
```

## Security notes (important)
- Never commit `serviceAccountKey.json` or `.env` to public repo.
- Use environment secrets in production.
- Use HTTPS and secure storage for ticket files (S3 with signed URLs recommended).
- Add rate-limiting for OTP and sensitive endpoints.

If you want, I can:
- Create a downloadable zip of this repo (already prepared).
- Push this repo to GitHub for you (I will provide instructions and the prepared files).
- Configure Twilio sandbox configuration steps or 360dialog help.
