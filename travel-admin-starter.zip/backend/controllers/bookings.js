const pool = require('../pool');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const { sendWhatsAppViaTwilio, sendWhatsAppVia360dialog } = require('../whatsapp');

exports.list = async (req,res)=>{
  const [rows] = await pool.query('SELECT b.*, u.email AS user_email, u.name AS user_name FROM bookings b LEFT JOIN users u ON b.user_id = u.id ORDER BY b.created_at DESC LIMIT 500');
  res.json({data:rows});
};

exports.get = async (req,res)=>{
  const id = req.params.id;
  const [rows] = await pool.query('SELECT b.*, u.email AS user_email FROM bookings b LEFT JOIN users u ON b.user_id = u.id WHERE b.id=?',[id]);
  if(!rows.length) return res.status(404).json({error:'Not found'});
  res.json(rows[0]);
};

exports.updateStatus = async (req,res)=>{
  const id = req.params.id;
  const {status} = req.body;
  await pool.query('UPDATE bookings SET status=? WHERE id=?',[status, id]);
  await pool.query('INSERT INTO admin_logs (admin_id, action, meta) VALUES (?, ?, ?)', [req.admin.id, 'update_booking_status', JSON.stringify({bookingId:id,status})]);
  res.json({ok:true});
};

exports.uploadTicket = async (req,res)=>{
  try{
    const bookingId = req.params.id;
    if(!req.file) return res.status(400).json({error:'No file'});
    const filePath = req.file.path;
    // Save ticket record
    await pool.query('INSERT INTO tickets (booking_id, admin_id, file_path, issued_at) VALUES (?, ?, ?, NOW())', [bookingId, req.admin.id, filePath]);
    await pool.query('UPDATE bookings SET status = ? WHERE id = ?', ['ticketed', bookingId]);

    // Optionally send WhatsApp to user with ticket link
    const [brows] = await pool.query('SELECT b.*, u.phone, u.email FROM bookings b LEFT JOIN users u ON b.user_id = u.id WHERE b.id=?',[bookingId]);
    const booking = brows[0];
    if(booking && booking.phone){
      const base = process.env.FILES_BASE_URL || '';
      const fileUrl = base ? (base + '/' + encodeURIComponent(path.basename(filePath))) : ('Ticket attached by admin (server file path: ' + filePath + ')');
      const message = `Your ticket for ${booking.from_city} → ${booking.to_city} on ${booking.depart_date} is issued. Download: ${fileUrl}`;
      // try Twilio first if configured
      if(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_WHATSAPP_FROM){
        await sendWhatsAppViaTwilio(booking.phone, message);
      } else if(process.env.DIALOG_API_TOKEN){
        await sendWhatsAppVia360dialog(booking.phone, message);
      }
    }

    res.json({ok:true});
  }catch(err){
    console.error(err);
    res.status(500).json({error:err.message});
  }
};
